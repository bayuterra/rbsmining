<?php


//Playing Data

$uid = "xxxxxxxxxxx";

$cred = "xxxxxxxxxx";


//Withdraw Data

$email_coinbase = "xxxxxxxx@gmail.com";
$version = "44";
